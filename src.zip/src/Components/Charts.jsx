import { Box, Heading } from '@chakra-ui/react'
import React from 'react'

const Charts = () => {
  return (
    <div>
   <Box className="w-[100%] h-[60px] mt-[-660px]  ">
        <Heading  color="white" textAlign="center">Charts & Map Page</Heading>
      </Box>
    </div>
  )
}

export default Charts